using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using UnityEngine;

public class PotionBottle : Item {

    [SerializeField]
    private MeshRenderer _renderer;

    private Material _defaultMaterial;
    
    private void Start() {
        ItemType = ItemType.EmptyBottle;
        _defaultMaterial = _renderer.material;
        UpdateVisuals();
    }

    public void Fill(Kettle kettle) {
        ItemType = PotionUtil.GetCompountItemType(kettle.GetItems());
        Debug.Log($"{gameObject.name} content: {ItemType}");
        UpdateVisuals();
    }

    public ItemType Empty() {
        var result = ItemType;
        ItemType = ItemType.EmptyBottle;
        UpdateVisuals();
        Debug.Log($"{gameObject.name} emptied");
        return result;
    }

    private void UpdateVisuals() {
        var material = PotionConfig.GetPotionMaterial(ItemType);
        Debug.Log($"material {material}");
        Debug.Log($"_defaultMaterial {_defaultMaterial}");
        if (material != null) {
            _renderer.material = material;
        }
        else {
            _renderer.material = _defaultMaterial;
        }
        _renderer.material.SetColor("_PotionColor", PotionConfig.GetPotionColor(ItemType));
        
    }
    
//    [SerializeField]
//    private List<ItemType> _content = new List<ItemType>();
//
//    private void Start() {
//        ItemType = ItemType.PotionBottle;
//    }
//
//    public void Fill(Kettle kettle) {
//        _content = kettle.GetItems();
//        Debug.Log($"{gameObject.name} content: {String.Join(", ", _content)}");
//        UpdateVisuals();
//    }
//
//    public List<ItemType> Empty() {
//        var items = new List<ItemType>(_content);
//        _content.Clear();
//        UpdateVisuals();
//        Debug.Log($"{gameObject.name} emptied");
//        return items;
//    }
//
//    public bool IsEmpty() {
//        return _content.Count == 0;
//    }
//    
//
//    private void UpdateVisuals() {
//        Debug.Log($"TODO update potion bottle visuals");
//    }
}
