using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinSound : MonoBehaviour {
    private AudioSource _audioSource;
    
    void Start() {
        _audioSource = GetComponent<AudioSource>();
        GameEvents.OnScoreUpdate += OnScoreUpdate;
    }

    private void OnDestroy() {
        GameEvents.OnScoreUpdate -= OnScoreUpdate;
    }


    private void OnScoreUpdate(int value) {
        _audioSource.Play();
    }
}
