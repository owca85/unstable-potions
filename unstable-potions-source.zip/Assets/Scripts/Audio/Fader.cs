using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fader : MonoBehaviour {

    [SerializeField] private float _fadeInSpeed = 2f;
    [SerializeField] private float _fadeOutSpeed = 2f;
    
    private AudioSource _audioSource;

    private bool _shouldPlay;
    private float _initialVolume;
    
    void Start() {
        _audioSource = GetComponent<AudioSource>();
        _initialVolume = _audioSource.volume;
        _audioSource.volume = 0;
        _audioSource.Play();
    }

    public void SetState(bool state) {
        _shouldPlay = state;
    }
    
    void Update()
    {
        if (_shouldPlay) {
            _audioSource.volume = Mathf.Lerp(_audioSource.volume, _initialVolume, Time.deltaTime * _fadeInSpeed);
        }
        else {
            _audioSource.volume =Mathf.Lerp(_audioSource.volume, 0, Time.deltaTime * _fadeOutSpeed);
        }
    }
}
