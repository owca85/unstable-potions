using UnityEngine;

public class GameState : MonoBehaviour {

    public static GameState Instance;

    [SerializeField] private float _timeLimit;
    
    [SerializeField]
    private int _score;
    private float _timeLeft;
    private bool _isGameOver;
    
    private void Awake() {
        if (Instance != null) {
            Destroy(gameObject);
        }
        else {
            Instance = this;
        }
    }

    private void Start() {
        _timeLeft = _timeLimit;
        GameEvents.OnItemSold += OnItemSold;
    }

    private void OnDestroy() {
        GameEvents.OnItemSold -= OnItemSold;
    }

    private void Update() {
        if (_isGameOver) {
            return;
        }
        _timeLeft = Mathf.Max(0, _timeLeft - Time.deltaTime);
        if (_timeLeft <= 0) {
            _isGameOver = true;
            GameEvents.GameOver();
        }
    }

    public static int GetScore() {
        return Instance._score;
    }

    private void OnItemSold(ItemType itemType, int value) {
        Instance._score += value;
        GameEvents.ScoreUpdate(GetScore());
    }

    public static float GetTimeLeft() {
        return Instance._timeLeft;
    }

    public static bool IsGameOver() {
        return Instance._isGameOver;
    }
}