using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeliveryPoint : MonoBehaviour {
    private void OnMouseEnter() {
//        Debug.Log($"{gameObject} - OnMouseEnter");
    }

    private void OnMouseExit() {
//        Debug.Log($"{gameObject} - OnMouseExit");
    }

    private void OnMouseDown() {
        var item = Hand.GetCurrentItem();
        if (item.GetItemType() == ItemType.EmptyBottle) {
            return;
        }
        OrderManager.Instance.ResolveOrder(item.GetItemType());
        item.GetComponent<PotionBottle>()?.Empty();
        Hand.ReleaseCurrentItem();
    }
}