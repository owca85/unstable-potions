using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class OrderManager : MonoBehaviour {

    public static OrderManager Instance;
    
    [SerializeField] private int _maxConcurrentOrders = 1;
    [SerializeField] private int _orderInterval = 3;
    [SerializeField] private List<ItemType> _possibleItemTypes;
    [SerializeField] private float _easyTime = 10;
    [SerializeField] private float _mediumTime = 15;
    [SerializeField] private float _hardTime = 20;
//    [SerializeField] private List<PotionData> _potionData;
    [SerializeField] private List<OrderItem> _orderUiItems;
    
    [SerializeField] private GameObject _explosionPrefab;
    [SerializeField] private AudioSource _explosionAudioSource;
    
    
    [SerializeField] private List<Order> _orders = new List<Order>();
    

    private int _counter = 1;

    private void Awake() {
        if (Instance != null) {
            Destroy(gameObject);
        }
        else {
            Instance = this;
        }
    }

    void Start() {
        GameEvents.OnGameOver += OnGameOver;
        InvokeRepeating(nameof(TryAddOrder), _orderInterval, _orderInterval);
    }

    private void OnDestroy() {
        GameEvents.OnGameOver -= OnGameOver;
    }

    private void OnGameOver() {
        CancelInvoke();
    }
    
    private void TryAddOrder() {
        if (GameState.IsGameOver()) {
            return;
        }
        if (_orders.Count < _maxConcurrentOrders) {
            var type = RandomItemType();
            var time = GetTime(type);
            var order = new Order(type, time, _counter++);
            _orders.Insert(0, order);
            Debug.Log($"New order no. {order.Number} for {type} arrived. Time left: {time}");
            foreach (var orderUiItem in _orderUiItems) {
                if (orderUiItem.IsIdle()) {
                    orderUiItem.SetOrder(order, PotionConfig.GetPotionColor(order.ItemType));
                    break;
                }
            }
        }
    }

//    private Color GetPotionColor(ItemType itemType) {
//        return _potionData.Where(d => d.ItemType == itemType).Select(d => d.Color).First();
//    }

    private ItemType RandomItemType() {
        var result = _possibleItemTypes[Random.Range(0, _possibleItemTypes.Count)];
        if (result == ItemType.ComplexBlack && _orders.Find(o => o.ItemType == result) != null) {
            return RandomItemType();
        }

        return result;
    }

    private float GetTime(ItemType itemType) {
        switch (itemType) {
            case ItemType.ComplexBlack:
                return _hardTime;
            case ItemType.ComplexGreen:
            case ItemType.ComplexYellow:
                return _mediumTime;

            default:
                return _easyTime;
        }
    }

    void Update() {
        for (var i = _orders.Count - 1; i >= 0; i--) {
            var order = _orders[i];
            order.Update();
            if (order.TimeLeft <= 0) {
                _orders.RemoveAt(i);
//                Debug.Log($"Order no. {order.Number} ({order.ItemType}) lost.");
                ClearOrderUI(order);
            }
        }
    }

    public void ResolveOrder(ItemType itemType) {
        Debug.Log($"Resolving order for potion {itemType}");
        bool resovled = false;
        for (var i = _orders.Count - 1; i >= 0; i--) {
            var order = _orders[i];
            Debug.Log($"order: {order.ItemType}, timeleft: {order.TimeLeft}");
            if (order.TimeLeft > 0 && order.ItemType == itemType) {
                _orders.RemoveAt(i);
                Debug.Log($"Order no. {order.Number} ({order.ItemType}) COMPLETED.");
                GameEvents.SellItem(itemType, PotionConfig.GetPotionValue(itemType));
                ClearOrderUI(order);
                resovled = true;
                break;
            }
        }

        if (!resovled) {
            Explode();
        }
    }

    private void Explode() {
        Instantiate(_explosionPrefab, Hand.GetCurrentItem().transform.position, Quaternion.identity);
        _explosionAudioSource.Play();
        CameraShake.Instance.Shake();
    }

    private void ClearOrderUI(Order order) {
        foreach (var orderUiItem in _orderUiItems) {
            if (!orderUiItem.IsIdle()) {
                if (orderUiItem.GetOrder().Number == order.Number) {
                    orderUiItem.ClearOrder();    
                }
            }
        }
    }
    
    
    
    public class Order {
        public Order(ItemType itemType, float timeLeft, int number) {
            ItemType = itemType;
            TimeLeft = timeLeft;
            InitialTimeLeft = timeLeft;
            Number = number;
        }

        public ItemType ItemType { get; }
        public float TimeLeft { get; private set; }
        public float InitialTimeLeft { get; private set; }
        public int Number { get; }

        public void Update() {
            TimeLeft = Mathf.Max(0, TimeLeft - Time.deltaTime);
        }
    }
    
}