using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "PotionData", menuName = "ScriptableObjects/PotionData", order = 1)]
public class PotionData : ScriptableObject {
   
   public ItemType ItemType;
   public Color Color;
   public float MaxWaitingTime;
   public int GoldValue;
   public Material Material;
}
