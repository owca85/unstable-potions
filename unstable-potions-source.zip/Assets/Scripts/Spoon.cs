using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spoon : MonoBehaviour {

    [SerializeField]
    private Vector3 _kettleOffset;
    private Animator _animator;
    
    public bool IsAnimating { private set; get; }


    // Start is called before the first frame update
    void Start() {
        _animator = GetComponent<Animator>();
    }


    public void PlayAnimation(Kettle kettle) {
        transform.position = kettle.transform.position + _kettleOffset;
        _animator.SetTrigger("Play");
        Hand.SetCanMoveItem(false);
        IsAnimating = true;
        Invoke(nameof(OnAnimationEnd), 2.2f);
        Hand.ReleaseCurrentItem();
    }

    private void OnAnimationEnd() {
        IsAnimating = false;
        Hand.SetCanMoveItem(true);
    }
}
