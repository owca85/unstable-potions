using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class PotionConfig : MonoBehaviour
{
    public static PotionConfig Instance;
    
    [SerializeField] private List<PotionData> _potionData;
    
    private void Awake() {
        if (Instance != null) {
            Destroy(gameObject);
        }
        else {
            Instance = this;
        }
    }
    
    public static Color GetPotionColor(ItemType itemType) {
        var data = Instance._potionData.Find(d => d.ItemType == itemType);
        if (data != null) {
            return data.Color;
        }
        return GetPotionColor(ItemType.UnknownMixture);
    }
    
    public static Material GetPotionMaterial(ItemType itemType) {
        var data = Instance._potionData.Find(d => d.ItemType == itemType);
        if (data != null) {
            return data.Material;
        }

        return GetPotionMaterial(ItemType.UnknownMixture);
    }
    
    public static int GetPotionValue(ItemType itemType) {
        return Instance._potionData.Where(d => d.ItemType == itemType).Select(d => d.GoldValue).FirstOrDefault();
    }
}
