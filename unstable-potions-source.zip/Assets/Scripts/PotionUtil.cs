﻿using System;
using System.Collections.Generic;

public static class PotionUtil {
    private static readonly Dictionary<string, ItemType> Recipies = new Dictionary<string, ItemType> {
        {BuildKey(ItemType.BasicGreen, ItemType.BasicRed, ItemType.BasicYellow), ItemType.ComplexBlue},
        {BuildKey(ItemType.BasicGreen, ItemType.BasicRed, ItemType.BasicBlue), ItemType.ComplexPurple},
        {BuildKey(ItemType.BasicPurple, ItemType.BasicGreen, ItemType.BasicYellow), ItemType.ComplexRed},
        {BuildKey(ItemType.BasicBlue, ItemType.BasicPurple, ItemType.ComplexRed), ItemType.ComplexGreen},
        {BuildKey(ItemType.BasicYellow, ItemType.BasicGreen, ItemType.ComplexPurple), ItemType.ComplexYellow},
        {BuildKey(ItemType.BasicRed, ItemType.ComplexBlue, ItemType.ComplexRed), ItemType.ComplexBlack}
    };


    public static ItemType GetCompountItemType(List<ItemType> items) {
        if (items.Count == 0) {
            return ItemType.EmptyBottle;
        }

        if (items.Count == 1) {
            return items[0];
        }

        ItemType complexType;
        if (Recipies.TryGetValue(BuildKey(items), out complexType)) {
            return complexType;
        }

        return ItemType.UnknownMixture;

//        var compoundTypeName = String.Join("_", items);
//
//        return (Enum.IsDefined(typeof(ItemType), compoundTypeName))
//            ? (ItemType) Enum.Parse(typeof(ItemType), compoundTypeName)
//            : ItemType.UnknownMixture;
    }

    private static string BuildKey(List<ItemType> items) {
        return BuildKey(items.ToArray());
    }

    private static string BuildKey(params ItemType[] items) {
        return String.Join("_", items);
    }
}