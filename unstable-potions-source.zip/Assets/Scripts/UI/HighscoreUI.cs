using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class HighscoreUI : MonoBehaviour {

    public static HighscoreUI Instance;

    private const string PlayerId = "playerId";
    private const string PlayerName = "playerName";
    
    [SerializeField] private string _appId;
    [SerializeField] private string _apiUrl;
    [SerializeField] private TextAsset _appSecretFile;
    
    [Space]
    [SerializeField] private HighscorePanel _highscorePanel; 
    [SerializeField] private GameObject _summaryPanel; 
    [SerializeField] private TextMeshProUGUI _submitErrorMessage;
    [SerializeField] private TMP_InputField _playerName;
    [SerializeField] private Button _submitButton; 
    
    private HighscoreService _service;

    
    private void Awake() {
        if (Instance != null) {
            Destroy(gameObject);
        }
        else {
            Instance = this;
        }
        
        if (_appSecretFile == null) {
            Debug.LogError("missing file with appSecret key");
            return;
        }
        _service = new HighscoreService(_appId, _appSecretFile.text, _apiUrl);
    }

    private void Start() {
        GameEvents.OnGameOver += OnGameOver;
        if (PlayerPrefs.HasKey(PlayerName)) {
            _playerName.text = PlayerPrefs.GetString(PlayerName);
        }
    }

    private void OnDestroy() {
        GameEvents.OnGameOver -= OnGameOver;
    }

    private void OnGameOver() {
        _summaryPanel.SetActive(true);
//        _highscorePanel.gameObject.SetActive(true);
    }

    private void Update() {
        if (Input.GetKeyDown(KeyCode.R) && Input.GetKey(KeyCode.LeftControl)) {
            PlayerPrefs.DeleteAll();
            Debug.Log($"PlayerPrefs reset");
        }
    }

    public void SubmitScore(string playerId, string playerName, int score) {
        StartCoroutine(_service.SubmitScore(playerId, playerName, score, OnSubmitSuccess, OnSubmitFailure));
    }

    public void GetHighscores(string playerId) {
        _highscorePanel.ShowLoadingMessage();
        StartCoroutine(_service.GetHighscores(playerId, OnGetHighscoreSuccess, OnGetHighscoreFailure));
    }
    
    private void OnSubmitSuccess() {
        Debug.Log($"submit successful");
        _highscorePanel.gameObject.SetActive(true);
        GetHighscores(PlayerPrefs.GetString(PlayerId));
    }
    
    
    private void OnSubmitFailure(UnityWebRequest.Result result) {
        Debug.Log($"submit failed - {result}");
        _submitErrorMessage.enabled = true;
        Invoke(nameof(HideSubmitErrorMessage), 2f);
    }
    
    private void OnGetHighscoreSuccess(HighscoreResults results) {
        Debug.Log($"get highscores successful");
        _highscorePanel.ShowResults(results);
        _summaryPanel.SetActive(false);
        
    }
    
    
    private void OnGetHighscoreFailure(UnityWebRequest.Result result) {
        Debug.Log($"get highscore failed - {result}");
        _highscorePanel.ShowLoadingErrorMessage();
    }
    
    private void HideSubmitErrorMessage() {
        _submitErrorMessage.enabled = false;
    }

    public bool IsPlayerNameDefined() {
        return PlayerPrefs.HasKey(PlayerId) && PlayerPrefs.HasKey(PlayerName);
    }
    
    public string GeneratePlayerId(string playerName) {
        var id = $"{playerName}_{Guid.NewGuid()}";
        PlayerPrefs.SetString(PlayerId, id);
        PlayerPrefs.Save();
        Debug.Log($"generated player id: {id}");
        return id;
    }

    public void OnPlayerNameChanged() {
        _submitButton.interactable = _playerName.text.Length > 0;
        PlayerPrefs.SetString(PlayerName, _playerName.text);        
    }
    
    public void OnSubmitButton() {
        var playerName = _playerName.text;
        var playerId = IsPlayerNameDefined() ? PlayerPrefs.GetString(PlayerId) : GeneratePlayerId(playerName);
        PlayerPrefs.Save();
        SubmitScore(playerId, playerName, GameState.GetScore());
    }
}
