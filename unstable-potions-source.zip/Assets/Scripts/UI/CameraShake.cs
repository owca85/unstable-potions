using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

public class CameraShake : MonoBehaviour {

    public static CameraShake Instance;
    
    [SerializeField] private float _aplitude;
    [SerializeField] private float _duration;

    private float _currentMaxApltitude;
    private float _timeLeft;
    private Camera _camera;

    private Vector3 _initialPosition;

    private void Awake() {
        if (Instance != null) {
            Destroy(gameObject);
        }
        else {
            Instance = this;
        }
    }

    private void Start() {
        _camera = Camera.main;
    }

    void Update() {
        if (_currentMaxApltitude > 0) {
            _currentMaxApltitude = _aplitude * (1-(_duration - _timeLeft)/_duration);
            _timeLeft = Math.Max(0, _timeLeft - Time.deltaTime);
            _camera.transform.position = _initialPosition + Random.onUnitSphere * _currentMaxApltitude;
        }
        
    }

    public void Shake(float aplitudeFactor = 1, float durationFactor = 1) {
        if (_timeLeft > 0) {
            return;
        }
        _initialPosition = _camera.transform.position;
        _timeLeft = _duration * durationFactor;
        _currentMaxApltitude = _aplitude * aplitudeFactor;
    }
}