using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using TMPro;
using UnityEngine;
using Vector3 = UnityEngine.Vector3;

public class TimeUI : MonoBehaviour {

    private TextMeshProUGUI _text;
    private Vector3 _initialPosition;
    
    void Start() {
        _text = GetComponent<TextMeshProUGUI>();
        _initialPosition = _text.gameObject.transform.position;
    }

    void Update() {
        if (GameState.IsGameOver()) {
            transform.localScale = new Vector3(1, 1, 1);
            transform.position = _initialPosition;
            return;
        }
        var timeLeft = (int) GameState.GetTimeLeft();
        if (_text != null) {
            _text.text = $"Time left: {timeLeft}";
        }

        if (timeLeft < 20) {
            Blink();
        }
    }

    private void Blink() {
        var offset = Random.onUnitSphere*5;
        transform.position = _initialPosition + offset;
        transform.localScale = new Vector3(2,2,2);
    }
}
