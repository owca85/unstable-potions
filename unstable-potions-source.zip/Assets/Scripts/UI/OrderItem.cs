using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OrderItem : MonoBehaviour {
    [SerializeField] private Image _image;
    [SerializeField] private Image _bottleImage;
    [SerializeField] private Slider _timeSlider;

    private OrderManager.Order _order;

    // Start is called before the first frame update
    void Start() {
//        GameEvents.OnOrderTimeUpdate += OnOrderTimeUpdate;
        _image.enabled = false;
        _bottleImage.enabled = false;
        _timeSlider.gameObject.SetActive(false);

    }

    private void OnDestroy() {
//        GameEvents.OnOrderTimeUpdate -= OnOrderTimeUpdate;
    }

    public void SetOrder(OrderManager.Order order,Color color) {
        _order = order;
        _image.color = color;
        _image.enabled = true;
        _bottleImage.enabled = true;
        _timeSlider.gameObject.SetActive(true);
    }

    public OrderManager.Order GetOrder() {
        return _order;
    }
    
    public void ClearOrder() {
        _order = null;
        _image.enabled = false;
    }
    
    private void Update() {
        if (GameState.IsGameOver()) {
            return;
        }
        if (_order != null) {
            if (_timeSlider != null) {
                _timeSlider.value = 1 - ((_order.InitialTimeLeft - _order.TimeLeft) / _order.InitialTimeLeft);
            }
        }
    }

    
//    private Sprite GetImage(ItemType itemType) {
//        var sprite = Resources.Load<Sprite>($"Images/{itemType}.png");
//        Debug.Log($"Loaded sprite: {sprite}");
//        return sprite;
//    }

    public bool IsIdle() {
        return _order == null;
    }
    
//
//    private void OnOrderTimeUpdate(OrderManager.Order order, float timeLeftNormalized) {
//        if (_timeSlider != null) {
//            _timeSlider.value = timeLeftNormalized;
//        }
//    }
    
    
}