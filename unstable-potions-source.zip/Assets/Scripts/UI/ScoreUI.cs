using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ScoreUI : MonoBehaviour {
    private TextMeshProUGUI _text;
    
    void Start() {
        GameEvents.OnScoreUpdate += OnScoreUpdate;
        _text = GetComponent<TextMeshProUGUI>();
    }

    private void OnDestroy() {
        GameEvents.OnScoreUpdate -= OnScoreUpdate;
    }


    private void OnScoreUpdate(int score) {
        _text.text = $"Score: {score}";
    }
}
