using System;

public static class GameEvents {
    public static event Action OnGameOver;
    public static event Action<int> OnScoreUpdate;
    public static event Action<Item> OnItemSelected;
    public static event Action<Item> OnItemDeselected;
    public static event Action<ItemType, int> OnItemSold;
    public static event Action<OrderManager.Order, float> OnOrderTimeUpdate;
    

    public static void GameOver() => OnGameOver?.Invoke();
    public static void ScoreUpdate(int score) => OnScoreUpdate?.Invoke(score);
    public static void SelectItem(Item item) => OnItemSelected?.Invoke(item);
    public static void DeselectItem(Item item) => OnItemDeselected?.Invoke(item);
    public static void SellItem(ItemType itemType, int value) => OnItemSold?.Invoke(itemType, value);
    public static void OrderTimeUpdate(OrderManager.Order order, float timeLeftNormalized) => OnOrderTimeUpdate?.Invoke(order, timeLeftNormalized);
    
}