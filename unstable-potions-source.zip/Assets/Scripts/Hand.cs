using UnityEngine;
using UnityEngine.UI;

public class Hand : MonoBehaviour {
    private static Hand _instance;

    [SerializeField] private GameObject _hoverPlane;

    private Item _currentItem;

    private bool _canMoveItem = true;
    
    private void Awake() {
        if (_instance != null) {
            Destroy(gameObject);
        }
        else {
            _instance = this;
        }
    }

    private void Start() {
        GameEvents.OnItemSelected += OnItemSelected;
    }

    private void OnDestroy() {
        GameEvents.OnItemSelected -= OnItemSelected;
    }

    private void Update() {
        if (GameState.IsGameOver()) {
            return;
        }
        
        if (Input.GetMouseButtonDown(1)) {
            if (_currentItem != null) {
                GameEvents.DeselectItem(_currentItem);
//                Debug.Log($"Item {_currentItem} deselected");
                ReleaseCurrentItem();
//                _currentItem.SetIsHeld(false);
//                _currentItem = null;
            }
        }

        
        if (_currentItem != null && _canMoveItem) {
            var mousePosition = Input.mousePosition;
            var depth = _hoverPlane.transform.position.z - Camera.main.transform.position.z;
            var worldPoint = Camera.main.ScreenToWorldPoint(new Vector3(mousePosition.x, mousePosition.y, depth));
            worldPoint.y = Mathf.Max(worldPoint.y, _hoverPlane.transform.position.y);

            _currentItem.transform.position = worldPoint;
        }
    }

    private void OnItemSelected(Item item) {
        if (_currentItem != null) {
            Debug.Log($"already holding an item");
            return;
        }

        Debug.Log($"Picked up {item}");
        PickupItem(item);
        _canMoveItem = true;
//        _currentItem = item;
//        _currentItem.SetIsHeld(true);
    }

    public static Item GetCurrentItem() {
        return _instance._currentItem;
    }

    public static void ReleaseCurrentItem() {
        _instance._currentItem.SetIsHeld(false);
        _instance._currentItem = null;
    }
    
    public static void PickupItem(Item item) {
        _instance._currentItem = item;
        _instance._currentItem.SetIsHeld(true);
    }

    public static void SetCanMoveItem(bool canMoveItem) {
        _instance._canMoveItem = canMoveItem;
    }
}