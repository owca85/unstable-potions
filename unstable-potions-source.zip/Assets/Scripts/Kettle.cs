using System;
using System.Collections.Generic;
using UnityEngine;
using Random = System.Random;

public class Kettle : MonoBehaviour {
    [SerializeField] private float _timeToOvercook = 3;
    [SerializeField] private float _maxBoilingTime = 3;
    [SerializeField] private ParticleSystem _cookingParticleSystem;
    [SerializeField] private ParticleSystem _boilingParticleSystem;
    [SerializeField] private AudioSource _explosionAudioSource;
    [SerializeField] private MeshRenderer _waterRenderer;
    [SerializeField] private List<AudioClip> _waterSounds; 
    [SerializeField] private AudioSource _waterSoundSource; 

//    [SerializeField] private AudioMixer _audioMixer;
//    [SerializeField] private AudioMixerSnapshot _boilingEnabledAudioSnapshot;
//    [SerializeField] private AudioMixerSnapshot _boilingDisabledAudioSnapshot;
    [SerializeField] private Fader _boilingFader;
    [SerializeField] private GameObject _explosionPrefab;
    [SerializeField] private Transform _explosionPoint;
    [SerializeField] private ParticleSystem _steamParticleSystem;


    [SerializeField] private List<ItemType> _content;


    private bool _isCooking;
    private float _overcookCounter;

    // Start is called before the first frame update
    void Start() {
        _content = new List<ItemType>();
        GameEvents.OnGameOver += OnGameOver;
    }

    private void OnDestroy() {
        GameEvents.OnGameOver -= OnGameOver;
    }

    void OnGameOver() {
        Invoke(nameof(Explode), UnityEngine.Random.Range(0f, .5f));
    }
    
    // Update is called once per frame
    void Update() {
        if (_isCooking) {
            _overcookCounter = Math.Min(_timeToOvercook + _maxBoilingTime, _overcookCounter + Time.deltaTime);
            if (_overcookCounter >= _timeToOvercook) {
                if (_overcookCounter >= _timeToOvercook + _maxBoilingTime) {
                    Explode();
                }
            }
        }
        else {
            _overcookCounter = Mathf.Max(0, _overcookCounter - Time.deltaTime * 10);
        }

        UpdateSteam(_isCooking && _overcookCounter >= _timeToOvercook);
        UpdateBolilingSound(_isCooking && _overcookCounter >= _timeToOvercook);
        UpdateParticleEffect(_boilingParticleSystem, _isCooking && _overcookCounter >= _timeToOvercook);
        UpdateParticleEffect(_cookingParticleSystem, _isCooking);
        UpdateShader();
    }

    private void UpdateSteam(bool shouldPlay) {
        if (shouldPlay && !_steamParticleSystem.isEmitting) {
            _steamParticleSystem.Play();
        }
        else if (!shouldPlay && _steamParticleSystem.isEmitting) {
            _steamParticleSystem.Stop();
        }
    }

    private void UpdateBolilingSound(bool shouldPlay) {
        _boilingFader.SetState(shouldPlay);
    }

    private void PlayRandomWaterSound() {
        var clip = _waterSounds[UnityEngine.Random.Range(0, _waterSounds.Count)];
        _waterSoundSource.PlayOneShot(clip);
    }
    
    private void UpdateShader() {
        if (_isCooking) {
            _waterRenderer.material.SetFloat("_Colorize",
                Mathf.Lerp(_waterRenderer.material.GetFloat("_Colorize"), 0.8f, Time.deltaTime));
            _waterRenderer.material.SetFloat("_Intensity",
                Mathf.Lerp(_waterRenderer.material.GetFloat("_Intensity"), 0.2f, Time.deltaTime));
        }
        else {
            _waterRenderer.material.SetFloat("_Colorize",
                Mathf.Lerp(_waterRenderer.material.GetFloat("_Colorize"), 0, Time.deltaTime * 10));
            _waterRenderer.material.SetFloat("_Intensity",
                Mathf.Lerp(_waterRenderer.material.GetFloat("_Intensity"), 0.05f, Time.deltaTime));
        }
    }

    private void UpdateParticleEffect(ParticleSystem particleSystem, bool enabled) {
        if (particleSystem == null) {
            return;
        }

        if (enabled && particleSystem.isStopped) {
            particleSystem.Play();
        }

        if (!enabled && particleSystem.isPlaying) {
            particleSystem.Stop();
        }
    }

    private void OnMouseEnter() {
//        Debug.Log($"{gameObject} - OnMouseEnter");
    }

    private void OnMouseExit() {
//        Debug.Log($"{gameObject} - OnMouseExit");
    }

    private void AnimateItem(Item item) {
        item.GetComponent<IngredientAnimation>()?.PlayAnimation(this);
    }
    
    private void OnMouseDown() {
        var item = Hand.GetCurrentItem();
        if (item != null) {
            switch (item.GetItemType()) {
                case ItemType.Neutralizer:
                    EmptyKettle();
                    AnimateItem(item);
                    PlayRandomWaterSound();
                    break;
                case ItemType.EmptyBottle:
                    if (_content.Count > 0) {
                        item.GetComponent<PotionBottle>().Fill(this);
                        EmptyKettle();
                        PlayRandomWaterSound();
                    }

                    break;
                case ItemType.Spoon:
                    _overcookCounter = 0;
                    item.GetComponent<Spoon>().PlayAnimation(this);
                    break;
                default:
                    AddItem(item.GetItemType());
                    item.GetComponent<PotionBottle>()?.Empty();
                    Debug.Log($"Items in {gameObject}: {String.Join(", ", _content)}");
                    if (_content.Count == 1) {
                        StartCooking();
                    }
                    AnimateItem(item);
                    PlayRandomWaterSound();

                    break;
            }
        }
    }

    private void EmptyKettle() {
        _content.Clear();
        Debug.Log($"TODO Update kettle visuals");
        StopCooking();
    }

    private void AddItem(ItemType itemType) {
        _content.Add(itemType);
        Debug.Log($"{itemType} added to {gameObject.name}");
        ValidateMixture();
    }

    private void ValidateMixture() {
        if (_content.Count > 3) {
//            Debug.Log($"{gameObject.name} BOOM!! (unstable mixture)");
            Explode();
        }
    }

    private void StartCooking() {
        Debug.Log($"{gameObject} - started cooking");
        _isCooking = true;
//        _overcookCounter = 0;
    }

    private void StopCooking() {
        Debug.Log($"{gameObject} - stopped cooking");
        _isCooking = false;
//        _overcookCounter = 0;
    }

    public List<ItemType> GetItems() {
        return new List<ItemType>(_content);
    }

    private void Explode() {
        PlayExplosionSound();
        Instantiate(_explosionPrefab, _explosionPoint.position, Quaternion.identity);
        EmptyKettle();
        CameraShake.Instance.Shake();
    }

    private void PlayExplosionSound() {
        _explosionAudioSource.Play();
    }
}