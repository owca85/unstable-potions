using UnityEngine;

public class Item : MonoBehaviour {
    [SerializeField] protected ItemType ItemType;

    [SerializeField] private float _returnSpeed = 1;

    
    private Vector3 _originalPosition;
    
    private bool _isHeld;

    private Spoon _spoon; //dirty hack

    private void Awake() {
        _originalPosition = gameObject.transform.position;
        if (ItemType == ItemType.Spoon) {
            _spoon = GetComponent<Spoon>();
        }
    }

    private void Update() {
        if (ItemType == ItemType.Spoon && _spoon.IsAnimating) {
            return;
        }

        if (!_isHeld) {
            transform.position = Vector3.Lerp(transform.position, _originalPosition,
                _returnSpeed * Time.deltaTime * 10);
        }
    }

    private void OnMouseEnter() {
//        Debug.Log($"Item {ItemType} - OnMouseEnter");
    }

    private void OnMouseExit() {
//        Debug.Log($"Item {ItemType} - OnMouseExit");
    }

    private void OnMouseDown() {
//        Debug.Log($"Item {ItemType} - OnMouseDown");
        GameEvents.SelectItem(this);
    }

    public ItemType GetItemType() {
        return ItemType;
    }

    public void SetIsHeld(bool isHeld) {
        _isHeld = isHeld;
        GetComponentInChildren<Collider>().enabled = !isHeld;
    }
}