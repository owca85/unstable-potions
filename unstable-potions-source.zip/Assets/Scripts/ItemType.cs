﻿public enum ItemType {
    Neutralizer,
    EmptyBottle,
    UnknownMixture,
    Spoon,
    
    
    BasicRed,
    BasicGreen,
    BasicBlue,
    BasicPurple,
    BasicYellow,
    
    ComplexRed,
    ComplexGreen,
    ComplexBlue,
    ComplexPurple,
    ComplexYellow,
    ComplexBlack,
}