using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IngredientAnimation : MonoBehaviour {

    [SerializeField] private float _animationSpeed = 5;
    [SerializeField] private GameObject _model;
    
    [SerializeField]
    private Vector3 _offset;
    private Animator _animator;


    private Vector3 _initialModelPosition;
    private Vector3 _targetModelPosition;
    
    private Quaternion _initialRotation;
    private Quaternion _reversedRotation;
    
    public bool IsAnimating { private set; get; }

    // Start is called before the first frame update
    void Start() {
        _animator = GetComponent<Animator>();
        _initialRotation = transform.localRotation;
        _reversedRotation = _initialRotation * Quaternion.Euler(0, 0, 110);

        _initialModelPosition = _model.transform.localPosition;
        
    }

    private void Update() {
        _targetModelPosition = _initialModelPosition + _offset;
        
        if (IsAnimating) {
            transform.rotation = Quaternion.Lerp(transform.rotation, _reversedRotation, Time.deltaTime * _animationSpeed);
            _model.transform.localPosition = Vector3.Lerp(_model.transform.localPosition, _targetModelPosition,
                Time.deltaTime * _animationSpeed);
        }
        else {
            transform.rotation = Quaternion.Lerp(transform.rotation, _initialRotation, Time.deltaTime* _animationSpeed);
            _model.transform.localPosition = Vector3.Lerp(_model.transform.localPosition, _initialModelPosition,
                Time.deltaTime * _animationSpeed);
        }
    }

    public void PlayAnimation(Kettle kettle) {
        IsAnimating = true;
//        transform.rotation = Quaternion.Lerp(transform.rotation, _reversedRotation, Time.deltaTime*10);
//        transform.position = kettle.transform.position + _kettleOffset;
//        _animator.SetTrigger("Play");
        Hand.SetCanMoveItem(false);
//        IsAnimating = true;
        Invoke(nameof(OnAnimationEnd), .5f);
//        Hand.ReleaseCurrentItem();
    }

    private void OnAnimationEnd() {
        IsAnimating = false;
        Hand.SetCanMoveItem(true);
    }
}
