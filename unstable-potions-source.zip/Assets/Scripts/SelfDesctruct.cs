using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelfDesctruct : MonoBehaviour {
    [SerializeField] private float _timeToLive;
    
    void Start()
    {
        Destroy(gameObject, _timeToLive);
    }
}
